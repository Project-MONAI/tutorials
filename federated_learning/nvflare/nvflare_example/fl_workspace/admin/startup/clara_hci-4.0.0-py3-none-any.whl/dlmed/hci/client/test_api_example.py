import argparse
import time

from dlmed.hci.client.api import AdminAPI

#
# Client Commands
# -------------------------------------------------------------------------------------------
# | SCOPE         | COMMAND         | DESCRIPTION                                           |
# -------------------------------------------------------------------------------------------
# | file_transfer | download_binary | download one or more binary files in the download_dir |
# | file_transfer | download_folder | download a folder from the server                     |
# | file_transfer | download_text   | download one or more text files in the download_dir   |
# | file_transfer | info            | show folder setup info                                |
# | file_transfer | upload_folder   | upload a folder to the server                         |
# -------------------------------------------------------------------------------------------
#
# Server Commands
# --------------------------------------------------------------------------------
# | SCOPE      | COMMAND           | DESCRIPTION                                 |
# --------------------------------------------------------------------------------
# | authz      | eval_right        | check if a user has a right on a site       |
# | authz      | eval_rule         | evaluate a site against a rule              |
# | authz      | show_config       | show authorization config                   |
# | authz      | show_info         | show general info of authorization policy   |
# | authz      | show_rights       | show rights configured for authorization    |
# | authz      | show_rules        | show rules configured for authorization     |
# | authz      | show_sites        | show sites configured for authorization     |
# | authz      | show_users        | show users configured for authorization     |
# | sys        | sys_info          | get the system info                         |
# | training   | abort             | abort the FL server/client training         |
# | training   | check_status      | check_status the FL server/client           |
# | training   | delete_run_number | delete the FL training run number           |
# | training   | deploy            | deploy MMAR to client/server                |
# | training   | remove_client     | remove_client the FL client                 |
# | training   | restart           | restart the FL server/client                |
# | training   | set_run_number    | set the FL training run number              |
# | training   | set_timeout       | set the admin commands timeout              |
# | training   | shutdown          | shutdown the FL server/client               |
# | training   | start             | start the FL server/client training         |
# | training   | start_mgpu        | start the FL client training with multi-gpu |
# | utils      | cat               | show content of a file                      |
# | utils      | env               | show system environment vars                |
# | utils      | grep              | search for PATTERN in a file.               |
# | utils      | head              | print the first 10 lines of a file          |
# | utils      | ls                | list files in work dir                      |
# | utils      | pwd               | print the name of work directory            |
# | utils      | tail              | print the last 10 lines of a file           |
# | validation | taskname          | get the FL taskname                         |
# | validation | validate          | cross sites validation                      |
# --------------------------------------------------------------------------------
#
#
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:33:32.039049', 'data': [{'type': 'string', 'data': 'FL run number:5\nFL server status: training stopped'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# now with 2 clients:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-26 14:13:59.665461', 'data': [{'type': 'string', 'data': 'FL run number has not been set.\nFL server status: training not started'}, {'type': 'string', 'data': 'Registered clients: 2 '}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', '090f0648-54f6-4ca9-9f9f-8c1723bab383', ''], ['org2', '242d1364-4528-4dad-b65b-11f5ead6a65a', '']]}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status client
# {'time': '2021-02-25 22:33:32.048596', 'data': [{'type': 'string', 'data': 'instance:org1-a : client name: org1-a\ttoken: fd808911-376d-4884-b991-1b1e3f275c41\tstatus: training stopped\n'}], 'status': 'SUCCESS'}
#
# now with 2 clients:
# ISSUING COMMAND: check_status client
# {'time': '2021-02-26 14:13:59.676606', 'data': [{'type': 'string', 'data': 'instance:org1-a : client name: org1-a\ttoken: 090f0648-54f6-4ca9-9f9f-8c1723bab383\tstatus: training not started\ninstance:org2 : client name: org2\ttoken: 242d1364-4528-4dad-b65b-11f5ead6a65a\tstatus: training not started\n'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: set_run_number 3
# {'time': '2021-02-25 22:33:37.470757', 'data': [{'type': 'string', 'data': 'Create a new run folder: run_3'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: upload_folder seg_ct_spleen
# {'time': '2021-02-25 22:33:37.480575', 'data': [{'type': 'string', 'data': 'Created folder /workspace/fordemo3.1flprov/server/startup/../transfer/seg_ct_spleen'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: deploy seg_ct_spleen server
# {'time': '2021-02-25 22:33:37.495601', 'data': [{'type': 'string', 'data': 'mmar_server has been deployed.'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: deploy seg_ct_spleen client
# {'time': '2021-02-25 22:33:37.507018', 'data': [{'type': 'string', 'data': 'instance:org1-a : MMAR deployed.\n'}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: deploy seg_ct_spleen client
# {'time': '2021-02-26 14:14:06.607766', 'data': [{'type': 'string', 'data': 'instance:org2 : MMAR deployed.\ninstance:org1-a : MMAR deployed.\n'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: start server
# {'time': '2021-02-25 22:33:47.833975', 'data': [{'type': 'string', 'data': 'Server training is starting....'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:33:57.856943', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training starting\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-26 14:14:33.118361', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training starting\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 2 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', '090f0648-54f6-4ca9-9f9f-8c1723bab383', ''], ['org2', '242d1364-4528-4dad-b65b-11f5ead6a65a', '']]}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: start client
# {'time': '2021-02-25 22:33:57.864221', 'data': [{'type': 'string', 'data': 'instance:org1-a : Start the client...\n'}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: start client
# {'time': '2021-02-26 14:14:33.129228', 'data': [{'type': 'string', 'data': 'instance:org1-a : Start the client...\ninstance:org2 : Start the client...\n'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status client
# {'time': '2021-02-25 22:34:02.586220', 'data': [{'type': 'string', 'data': 'instance:org1-a : client name: org1-a\ttoken: fd808911-376d-4884-b991-1b1e3f275c41\tstatus: training starting\n'}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: check_status client
# {'time': '2021-02-26 14:14:33.439538', 'data': [{'type': 'string', 'data': 'instance:org1-a : client name: org1-a\ttoken: 090f0648-54f6-4ca9-9f9f-8c1723bab383\tstatus: training starting\ninstance:org2 : client name: org2\ttoken: 242d1364-4528-4dad-b65b-11f5ead6a65a\tstatus: training starting\n'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:34:03.175261', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training starting\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-26 14:14:34.049482', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training starting\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 2 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', '090f0648-54f6-4ca9-9f9f-8c1723bab383', ''], ['org2', '242d1364-4528-4dad-b65b-11f5ead6a65a', '']]}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:34:53.201417', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training started\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-26 14:16:14.135636', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training started\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 2 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', '090f0648-54f6-4ca9-9f9f-8c1723bab383', ''], ['org2', '242d1364-4528-4dad-b65b-11f5ead6a65a', '']]}], 'status': 'SUCCESS'}
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:35:43.257092', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training started\nrun number:3\tstart round:0\tmax round:2\tcurrent round:0\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# this then repeats to check as current round increments:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:39:03.422403', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training started\nrun number:3\tstart round:0\tmax round:2\tcurrent round:1\nmin_num_clients:1\tmax_num_clients:100'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'string', 'data': 'Total number of clients submitted models: 0'}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# then training stops after all rounds (only 2 rounds here for testing, but real FL will have a lot more)
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:41:33.533732', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training stopped'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# with 2 clients:
# ISSUING COMMAND: check_status server
# {'time': '2021-02-26 14:26:14.791956', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training stopped'}, {'type': 'string', 'data': 'Registered clients: 2 '}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', '090f0648-54f6-4ca9-9f9f-8c1723bab383', ''], ['org2', '242d1364-4528-4dad-b65b-11f5ead6a65a', '']]}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: check_status server
# {'time': '2021-02-25 22:45:43.746409', 'data': [{'type': 'string', 'data': 'FL run number:3\nFL server status: training stopped'}, {'type': 'string', 'data': 'Registered clients: 1 '}, {'type': 'table', 'rows': [['CLIENT NAME', 'TOKEN', 'SUBMITTED MODEL'], ['org1-a', 'fd808911-376d-4884-b991-1b1e3f275c41', '']]}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: abort server (abort twice because first may start cross site validation for clients but we will not demo that part)
# {'time': '2021-02-25 22:47:23.857414', 'data': [{'type': 'string', 'data': 'Trying to abort all clients before abort server ...'}, {'type': 'string', 'data': 'instance:org1-a : Client training already stopped.\n'}, {'type': 'string', 'data': 'FL training has been stopped.'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: abort server
# {'time': '2021-02-25 22:47:24.469804', 'data': [{'type': 'string', 'data': 'Trying to abort all clients before abort server ...'}, {'type': 'string', 'data': 'instance:org1-a : Client training already stopped.\n'}, {'type': 'string', 'data': 'FL training has been stopped.'}], 'status': 'SUCCESS'}
#
# with 2 clients
# ISSUING COMMAND: abort server
# {'time': '2021-02-26 14:27:54.807406', 'data': [{'type': 'string', 'data': 'Trying to abort all clients before abort server ...'}, {'type': 'string', 'data': 'instance:org1-a : Aborted the client. \ninstance:org2 : Aborted the client. \n'}, {'type': 'string', 'data': 'FL training has been stopped.'}], 'status': 'SUCCESS'}
#
# ISSUING COMMAND: abort server
# {'time': '2021-02-26 14:27:55.720318', 'data': [{'type': 'string', 'data': 'Trying to abort all clients before abort server ...'}, {'type': 'string', 'data': 'instance:org1-a : Client training already stopped.\ninstance:org2 : Client training already stopped.\n'}, {'type': 'string', 'data': 'FL training has been stopped.'}], 'status': 'SUCCESS'}

def main():
    """
    Some of these are not used but kept for convenience with testing with previous admin.py of hci with simply replacing
    AdminClient with the API.

    With a previously provisioned project with an admin client, the admin client launching script (admin.py) can be
    replaced with this to use the API with the username being passed in do_cert_authentication_as in the example below.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--port', type=int, default=55550)
    parser.add_argument('--prompt', type=str, default='> ')
    parser.add_argument('--upload_dir', type=str, default='')
    parser.add_argument('--download_dir', type=str, default='')
    parser.add_argument('--cred_type', default='password')
    parser.add_argument('--with_ssl', action='store_true')
    parser.add_argument('--ca_cert', type=str, default='')
    parser.add_argument('--client_cert', type=str, default='')
    parser.add_argument('--client_key', type=str, default='')
    parser.add_argument('--with_debug', action='store_true')

    args = parser.parse_args()

    ca_cert = args.ca_cert
    client_cert = args.client_cert
    client_key = args.client_key

    if args.with_debug:
        print('SSL: {}'.format(args.with_ssl))
        print('Upload Dir: {}'.format(args.upload_dir))
        print('Download Dir: {}'.format(args.download_dir))

    print('Admin Server: {} on port {}'.format(args.host, args.port))

    api = AdminAPI(
        host=args.host,
        port=args.port,
        ca_cert=ca_cert,
        client_cert=client_cert,
        client_key=client_key,
        upload_dir=args.upload_dir,
        download_dir=args.download_dir,
        debug=args.with_debug
    )
    api.login(username="admin@nvidia.com")

    print(api.show_api_registered_commands([]))
    # commands are issued here to test and as example, it is possible to wrap this to make it less verbose
    api_test_command_wrapper(api, "check_status server")

    # api.do_command(command) and printing the command and reply is what happens in the wrapper

    api_test_command_wrapper(api, "help check_status")

    api_test_command_wrapper(api, "check_status server")

    api_test_command_wrapper(api, "check_status client")

    api_test_command_wrapper(api, "pwd server")

    api_test_command_wrapper(api, "cat server pid.fl")

    api_test_command_wrapper(api, "ls org2")

    api_test_command_wrapper(api, "ls server")  # "ls server -R"

    api_test_command_wrapper(api, "set_run_number 3")

    api_test_command_wrapper(api, "upload_folder seg_ct_spleen")

    api_test_command_wrapper(api, "deploy seg_ct_spleen server")

    api_test_command_wrapper(api, "deploy seg_ct_spleen client")
    time.sleep(10)
    api_test_command_wrapper(api, "start server")
    time.sleep(10)
    api_test_command_wrapper(api, "check_status server")

    api_test_command_wrapper(api, "start client")

    api_test_command_wrapper(api, "check_status client")
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(50)
    api_test_command_wrapper(api, "check_status server")
    time.sleep(100)
    api_test_command_wrapper(api, "abort server")

    api_test_command_wrapper(api, "abort server")

    api.logout()


def api_test_command_wrapper(api, command):
    print("\nISSUING COMMAND: {}".format(command))
    reply = api.do_command(command)
    print(reply)


if __name__ == "__main__":
    main()

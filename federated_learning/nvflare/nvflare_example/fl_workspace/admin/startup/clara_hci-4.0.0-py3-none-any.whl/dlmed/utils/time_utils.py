import time


def time_to_string(t):
    if t is None:
        return 'N/A'

    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(t))

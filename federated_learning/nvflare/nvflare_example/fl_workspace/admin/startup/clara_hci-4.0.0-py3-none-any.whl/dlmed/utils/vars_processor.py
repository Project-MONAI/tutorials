import os


class VarsProcessor(object):

    def process(self, all_vars: dict, **args):
        """
        Performs the additional variables tramsform processing.
        :return:
        """
        pass


class ClaraVarsProcessor(VarsProcessor):
    def process(self, all_vars: dict, **args):
        dataset_json = all_vars.get('DATASET_JSON', None)

        mmar_root = args.get('mmar_root')
        if dataset_json:
            dataset_json = os.path.join(mmar_root, dataset_json)
            all_vars['DATASET_JSON'] = dataset_json

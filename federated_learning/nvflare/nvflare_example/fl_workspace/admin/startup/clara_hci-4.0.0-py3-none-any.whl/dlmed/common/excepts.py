class ConfigError(Exception):
    """
    Raised when config parsing error happens
    """
    pass


class ErrorHandled(Exception):
    """
    Used to gracefully stop the program without printing exception error message
    """
    pass


class WorkFinished(Exception):
    """
    Used to declare work has finished
    """
    pass

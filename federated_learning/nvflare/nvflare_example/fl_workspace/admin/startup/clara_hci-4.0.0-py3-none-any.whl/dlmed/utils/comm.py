import threading


class Queue(object):

    def __init__(self, name):
        self.name = name
        self.items = []
        self._update_lock = threading.Lock()
        self.next_seq_no = 1

    def append(self, item):
        with self._update_lock:
            self.items.append(item)
            seq_no = self.next_seq_no
            self.next_seq_no += 1
            return seq_no

    def len(self):
        with self._update_lock:
            return len(self.items)

    def get(self, default=None):
        with self._update_lock:
            if len(self.items) > 0:
                result = self.items[0]
            else:
                result = default
        return result

    def pop(self, default=None):
        with self._update_lock:
            if len(self.items) > 0:
                result = self.items.pop(0)
            else:
                result = default
        return result

    def fill(self, data, limit):
        with self._update_lock:
            count = limit - len(self.items)
            if count > 0:
                for _ in range(count):
                    self.items.append(data)

    def clear(self):
        with self._update_lock:
            self.items = []


class Channel(object):

    def __init__(self, src, dest):
        self.src = src
        self.dest = dest
        self.req = Queue('req')
        self.reply = Queue('reply')

    def send(self, src, data):
        if src == self.src:
            self.req.append(data)
        elif src == self.dest:
            self.reply.append(data)

    def receive(self, src, default=None):
        if src == self.src:
            return self.reply.pop(default=default)
        elif src == self.dest:
            return self.req.pop(default=default)
        else:
            return default

    def __str__(self):
        return 'Channel({}<=>{})'.format(self.src.name, self.dest.name)

from dlmed.utils.wfconf import Configurator
from dlmed.utils.argument_utils import parse_vars
from dlmed.common.excepts import ConfigError
import os
import logging
import logging.config
import json

from .vars_processor import ClaraVarsProcessor


class ClaraConfiger(Configurator):

    def __init__(self,
                 base_pkgs: [str],
                 module_names: [str],
                 mmar_root: str,
                 wf_config_file_name: str,
                 env_config_file_name=None,
                 log_config_file_name=None,
                 kv_list=None,
                 default_vars=None,
                 num_passes: int = 1,
                 element_filter=None,
                 logging_config=True):
        if not isinstance(mmar_root, str):
            raise ConfigError('MMAR root must be str')

        if len(mmar_root) <= 0:
            raise ConfigError('MMAR root not specified')

        if not isinstance(wf_config_file_name, str):
            raise ConfigError('wf_config_file_name must be str')

        if len(wf_config_file_name) <= 0:
            raise ConfigError('workflow config file name not specified')

        if kv_list:
            assert isinstance(kv_list, list), 'cmd_vars must be list, but got {}'.format(type(kv_list))
            kv_vars = parse_vars(kv_list)
        else:
            kv_vars = {}

        if log_config_file_name is None:
            log_config_file_name = 'resources/log.config'

        self.log_config_file_name = log_config_file_name
        self.env_config_file_name = env_config_file_name

        if logging_config:
            log_config_file_path = os.path.join(mmar_root, log_config_file_name)
            assert os.path.isfile(log_config_file_path), 'missing log config file {}'.format(log_config_file_path)
            logging.config.fileConfig(fname=log_config_file_path, disable_existing_loggers=False)

        wf_config_file_name = os.path.join(mmar_root, wf_config_file_name)

        env_config = {}
        if env_config_file_name and len(env_config_file_name) > 0:
            with open(os.path.join(mmar_root, env_config_file_name)) as file:
                env_config = json.load(file)

        Configurator.__init__(self,
                              mmar_root=mmar_root,
                              cmd_vars=kv_vars,
                              default_vars=default_vars,
                              env_config=env_config,
                              wf_config_file_name=wf_config_file_name,
                              base_pkgs=base_pkgs,
                              module_names=module_names,
                              num_passes=num_passes,
                              element_filter=element_filter,
                              var_processor=ClaraVarsProcessor())

        self.logger = logging.getLogger(self.__class__.__name__)

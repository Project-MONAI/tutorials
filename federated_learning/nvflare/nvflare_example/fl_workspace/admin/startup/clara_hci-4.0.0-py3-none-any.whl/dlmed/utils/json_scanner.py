import copy
from dlmed.common.excepts import ConfigError


class Node(object):

    def __init__(self, element):
        self.parent = None
        self.element = element
        self.level = 0
        self.key = ''
        self.position = 0
        self.paths = []
        self.processor = None

    def path(self):
        if len(self.paths) <= 0:
            return ""

        return '.'.join(self.paths)

    def parent_element(self):
        if self.parent:
            return self.parent.element
        else:
            return None


def _child_node(node: Node, key, pos, element) -> Node:
    child = Node(element)
    child.processor = node.processor
    child.level = node.level + 1
    child.position = pos
    child.parent = node
    child.paths = copy.copy(node.paths)

    child.key = key
    if pos > 0:
        child.key = "#{}".format(pos)

    child.paths.append(child.key)
    return child


class JsonObjectProcessor(object):
    """
    JsonObjectProcessor is used to process JSON elements by the scan_json() function.

    """

    def process_element(self, node: Node):
        """
        This method is called by the scan() function for each JSON element scanned.

        Args:
            node: the node representing the JSON element

        Returns:

        """
        pass


class JsonScanner(object):

    def __init__(self, json_data: dict, location=None):
        assert isinstance(json_data, dict), 'json_data must be dict'
        self.location = location
        self.data = json_data

    def _do_scan(self, node: Node):
        try:
            node.processor.process_element(node)
        except Exception as ex:
            if self.location:
                raise ConfigError("Error parsing {} in JSON element {}: {}".format(self.location, node.path(), ex))
            else:
                raise ConfigError("Error in JSON element {}: {}".format(node.path(), ex))

        element = node.element

        if isinstance(element, dict):
            # need to make a copy of the element dict in case the processor modifies the dict
            iter_dict = copy.copy(element)
            for k, v in iter_dict.items():
                self._do_scan(_child_node(node, k, 0, v))
        elif isinstance(element, list):
            for i in range(len(element)):
                self._do_scan(_child_node(node, node.key, i+1, element[i]))

    def scan(self, processor: JsonObjectProcessor):
        assert isinstance(processor, JsonObjectProcessor), 'processor must be JsonObjectProcessor'
        node = Node(self.data)
        node.processor = processor
        self._do_scan(node)


import re


class _TestJsonProcessor(JsonObjectProcessor):

    def __init__(self):
        JsonObjectProcessor.__init__(self)

    def process_element(self, node: Node):
        pats = [
            '.\.pre_transforms\.#[0-9]+$',
            '^train\.model\.name$',
            '.\.search\.#[0-9]+$'
        ]
        path = node.path()
        print("Level: {}; Key: {}; Pos: {}; Path: {}".format(node.level, node.key, node.position, path))
        for p in pats:
            x = re.search(p, path)
            if x:
                print('\t {} matches {}'.format(path, p))


def _test():
    import json
    test_json = """
    {
     "learning_rate": 1e-4,
     "lr_search" : [1e-4, 2e-3],
     "train": {
      "model": {
        "name": "SegAhnet",
        "args": {
          "num_classes": 2,
          "if_use_psp": false,
          "pretrain_weight_name": "{PRETRAIN_WEIGHTS_FILE}",
          "plane": "z",
          "final_activation": "softmax",
          "n_spatial_dim": 3
        },
        "search": [
          {
            "type": "float",
            "args": ["num_classes"],
            "targets": [1,3],
            "domain": "net"
          },
          {
            "type": "float",
            "args": ["n_spatial_dim"],
            "targets": [2,5],
            "domain": "net"
          },
          {
            "type": "enum",
            "args": ["n_spatial_dim", "num_classes"],
            "targets": [[2,3],[3,4],[5,1]],
            "domain": "net"
          },
          {
            "type": "enum",
            "args": ["n_spatial_dim"],
            "targets": [[2],[3],[6],[12]],
            "domain": "net"
          }
        ]
      },
      "pre_transforms": [
      {
        "name": "LoadNifti",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "ConvertToChannelsFirst",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "ScaleIntensityRange",
        "args": {
          "fields": "image",
          "a_min": -57,
          "a_max": 164,
          "b_min": 0.0,
          "b_max": 1.0,
          "clip": true
        }
      },
      {
        "name": "FastCropByPosNegRatio",
        "args": {
          "size": [
            96,
            96,
            96
          ],
          "fields": "image",
          "label_field": "label",
          "pos": 1,
          "neg": 1,
          "batch_size": 3
        },
        "search": [
          {
            "domain": "transform",
            "type": "enum",
            "args": ["size"],
            "targets": [[[32, 32, 32]], [[64, 64, 64]], [[128, 128, 128]]]
          },
          {
            "domain": "transform",
            "type": "enum",
            "args": ["batch_size"],
            "targets": [[3], [4], [8], [10]]
          }
        ]
      },
      {
        "name": "RandomAxisFlip",
        "args": {
          "fields": [
            "image",
            "label"
          ],
          "probability": 0.0
        },
        "search": [
          {
            "domain": "transform",
            "type": "float",
            "args": ["probability#p"],
            "targets": [0.0, 1.0]
          },
          {
            "domain": "transform",
            "args": "DISABLED"
          }
        ]
      },
      {
        "name": "RandomRotate3D",
        "args": {
          "fields": [
            "image",
            "label"
          ],
          "probability": 0.0
        }
      },
      {
        "name": "ScaleIntensityOscillation",
        "args": {
          "fields": "image",
          "magnitude": 0.10
        }
      },
      {
        "name": "LoadNifti",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "LoadNifti",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "LoadNifti",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "LoadNifti",
        "args": {
          "fields": [
            "image",
            "label"
          ]
        }
      },
      {
        "name": "RandomAxisFlip",
        "args": {
          "fields": [
            "image",
            "label"
          ],
          "probability": 0.0
        },
        "search": [
          {
            "domain": "transform",
            "type": "float",
            "args": ["probability#p"],
            "targets": [0.0, 1.0]
          },
          {
            "domain": "transform",
            "args": "DISABLED"
          }
        ]
      }
    ]
    } }
    """
    train_config = json.loads(test_json)
    scanner = JsonScanner(train_config, "test")
    scanner.scan(_TestJsonProcessor())


if __name__ == '__main__':
    _test()
